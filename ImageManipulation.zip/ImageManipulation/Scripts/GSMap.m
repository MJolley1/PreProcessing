[X,map] = imread('millbrook.jpg');
imshow(X,map)

newmap = rgb2gray(map);
imshow(X,newmap)