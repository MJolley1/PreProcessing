%%%Convert lines into comment if you do not wish to run that feature

%%%Open image and display it as colour image
RGB = imread('millbrook.jpg');
    imshow(RGB)

%%%Convert RGB image to a grayscale and show image
I = rgb2gray(RGB);
    figure
    imshow(I)

%%%crop the image by selecting an area with your mouse, and double click
%%%it, then show this area
[J,rect] = imcrop(I);
    imshow(J)
    
uiwait(msgbox('Operation Completed, continue with imadjust?','Success','modal'));

%%%use the imadjust function to saturate the extremties and show
K = imadjust(J);
    figure
    imshowpair(J,K,'montage')
   
    
uiwait(msgbox('Operation Completed, continue with histeq?','Success','modal'));

%%% use the histeq to equalise the image and then do a side by side
%%% comparison of the before imadjust and histeq and after
L = histeq(K);
imshowpair(K,L,'montage')
    axis off
    
uiwait(msgbox('Operation Completed, continue with adapthisteq?','Success','modal'));
    
%%%CLAH feature and then compare the two
M = adapthisteq(L,'clipLimit',0.02,'Distribution','rayleigh');
imshowpair(L,M,'montage');
title('Original Image (left) and Contrast Enhanced Image (right)')

uiwait(msgbox('Operation Completed. Binarise result? NOTE: SHOULD ONLY BE USED IN EXTREME CIRCUMSTANCES','Success','modal'));
    
%%% for extremely difficult to see images, perform a binarisation
BW = imbinarize(M,'adaptive','ForegroundPolarity','dark','Sensitivity',0.4);
figure
imshowpair(L,BW,'montage')