%Convert lines into comment if you do not wish to run that feature using a
%percent sign on the lines you do not wish to carry out (do the whole
%section)

%% Open image and display it as colour image
%

    RGB = imread('millbrookTrim0.jpg');
     imshow(RGB)

%% Convert RGB image to a grayscale and show image
%


    I = rgb2gray(RGB);
        figure
        imshow(I)

%% crop the image by selecting an area with your mouse, and double click
%it, then show this area

targetSize = [1000 1000];
r = centerCropWindow2d(size(I),targetSize);
J = imcrop(I,r);

%or

%[J,rect] = imcrop(I);

imshow(J)

whos

answer = questdlg('Would you like to continue?', ...
	'Continue?', ...
	'Yes','No','Cancel','Cancel');
% Handle response
switch answer
    case 'Yes'
        disp([answer ' Continuing'])
        continue1 = 1;
    case 'No'
        disp([answer ' Ending'])
        continue1 = 0;
    case 'Cancel'
        disp('Cancelling')
        continue1 = 0;
end

%% use the imadjust function to saturate the extremties and show
%

K = imadjust(J);
    figure
    imshowpair(J,K,'montage')
   

%% use the histeq to equalise the image and then do a side by side
% comparison of the before imadjust and histeq and after

L = histeq(K);

    figure
     montage({J,K,L})
    
%% CLAH feature and then compare the two
% 

M1 = adapthisteq(K,'clipLimit',0.02,'Distribution','rayleigh');

M2 = adapthisteq(L,'clipLimit',0.02,'Distribution','rayleigh');
figure
   montage({J,K,L,M1,M2})
title('Original Image (left) and Contrast Enhanced Image (right)')


        
%% for extremely difficult to see images, perform a binarisation
%

BW0 = imbinarize(L,'adaptive','ForegroundPolarity','dark','Sensitivity',0.2);
BW1 = imbinarize(M1,'adaptive','ForegroundPolarity','dark','Sensitivity',0.2);
BW2 = imbinarize(M2,'adaptive','ForegroundPolarity','dark','Sensitivity',0.2);

figure
    montage({J,K,L,M,BW0,BW1,BW2})