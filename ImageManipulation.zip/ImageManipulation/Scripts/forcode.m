%load image: 
RGB = imread('millbrookTrim0.jpg');

for x= 0
    while x==0 
        
        answer = questdlg('Would you like to load the image?', ...
            'Continue?', ...
            'Yes','No','Cancel','Cancel');
        % Handle response
        switch answer
            case 'Yes'
                
                disp([answer ' Continuing']);
                figure
                imshow(RGB);
                title('Original Image')
                x = x + 1;
                newim = RGB;
            case 'No'
                disp([answer ' Ending'])
                x= x + 10;
                break;
            case 'Cancel'
                disp('Cancelling')
                x= x + 10;
break;

        end
        
    end
    
    while x == 1
        
        answer = questdlg('Would you like to grayscale the image (default = Yes)?', ...
            'Continue?', ...
            'Yes','No','Cancel','Yes');
        % Handle response
        switch answer
            case 'Yes'
                disp([answer ' Continuing']);
                I = rgb2gray(newim);
                figure;
                imshow(I);
                title('Grayscaled Image');
                x = x + 1;
                newim = I;
            case 'No'
                disp([answer ' Ending'])
                x = x + 1
            case 'Cancel'
                disp('Cancelling')
                x = x + 10
break;
        end
        
    end
    
    while x == 2
        answer = questdlg('Would you like to crop the image (default = 1000x1000)?', ...
            'Continue?', ...
            'Yes','No','Default','Yes');
        % Handle response
        switch answer
            case 'Yes'                
                    [J,rect] = imcrop(newim);
                    figure;
                    imshow(J);
                    title('Manually Cropped Image');
                    x = x + 1;
                    
                    newim = J;
                                   
            case 'No'
                disp([answer ' Ending'])
                x = x + 1
                
            case 'Default'
                    targetSize = [1000 1000];
                    r = centerCropWindow2d(size(newim),targetSize);
                    J = imcrop(newim,r);
                    figure;
                    imshow(J);
                    title('Default Cropped Image (1000x1000)');
                    x = x + 1;
                    
                    newim = J;            

break;
        end
        
    end
    
    while x== 3
        
        answer = questdlg('Would you like to perform imadjust (default = Yes)?', ...
            'Continue?', ...
            'Yes','No','Cancel','Yes');
        % Handle response
        switch answer
            case 'Yes'
               
                    K = imadjust(newim);
                    figure;
                    imshow(K);
                    title('Processed Image with "imadjust"');
                    imshowpair(J,K,'montage');
                    title('Comparison of Original Grayscaled Image (Left) with Processed Image (Right)');
                    x = x + 1;
                    newim = K;
            case 'No'
                disp([answer ' skipping']);
                x = x + 1;
             case 'Cancel'
                disp('Cancelling')
                x = x + 10
break;
        end
    end
    
    while x== 4
        
        answer = questdlg('Would you like to perform histeq?', ...
            'Continue?', ...
            'Yes','No','Cancel','Yes');
        % Handle response
        switch answer
            case 'Yes'
                L = histeq(newim);
                
                figure;
                imshow(L);
                title('Processed Image with "histeq"');
                montage({J,L});
                title('Comparison of Original Grayscaled Image (Left) with Processed Image (Right)');
                x = x + 1;
                newim = L;
            case 'No'
                disp([answer ' Ending'])
                x = x + 1
            case 'Cancel'
                disp('Cancelling')
                x = x + 10
break;
        end
    end
    
    while x == 5
        
        answer = questdlg('Would you like to perform adapthisteq?', ...
            'Continue?', ...
            'Yes','No','Cancel','Yes');
        % Handle response
        switch answer
            case 'Yes'
                M = adapthisteq(newim,'clipLimit',0.02,'Distribution','rayleigh');
                
                figure;
                imshow(M);
                title('Processed Image with "adapthisteq"');
                montage({J,M});
                title('Comparison of Original Grayscaled Image (Left) with Processed Image (Right)');
                x = x + 1;
                newim = M;
            case 'No'
                disp([answer ' Ending'])
                x = x + 1;
            case 'Cancel'
                disp('Cancelling')
                x = x + 10
break;
        end
    end
    
    while x == 6
        
        answer = questdlg('Would you like to perform imbinarize?', ...
            'Continue?', ...
            'Yes','No','Cancel','Yes');
        % Handle response
        switch answer
            case 'Yes'
                Bi = imbinarize(newim,'adaptive','ForegroundPolarity','dark','Sensitivity',0.2);
                figure
                imshow(Bi);
                title('Processed Image with "imbinarize"');
                montage({J, Bi});
                title('Comparison of Original Grayscaled Image (Left) with Processed Image (Right)');
                
                x = x + 1;
                newim = Bi
            case 'No'
                disp([answer ' Ending']);
                break;
            case 'Cancel'
                disp('Cancelling');
                x = x + 10
break;
        end
        while x > 6
            break
        end
    end   
end
