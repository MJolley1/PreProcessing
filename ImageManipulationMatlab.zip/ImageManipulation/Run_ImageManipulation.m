%Simply use this script to run the example of image manipulation. A pop up
%box will walk you through the process of applying various processes to an
%image.

run ImManip